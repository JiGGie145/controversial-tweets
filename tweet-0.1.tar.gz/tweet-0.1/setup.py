from setuptools import setup
setup(
    name="tweet",
    version="0.1",
    description="Paquete con la clase Tweet",
    author="lucas de francesca",
    author_email="lucasdfrancesca@gmail.com",
    url="",
    packages=['tweet']
)
