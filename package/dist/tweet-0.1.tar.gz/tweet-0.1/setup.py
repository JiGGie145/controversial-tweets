import setuptools

setuptools.setup(
    name="tweet",
    version="0.1",
    description="Clase Tweet",
    author="lucas de francesca",
    author_email="lucasdfrancesca@gmail.com",
    packages=setuptools.find_packages()
)
